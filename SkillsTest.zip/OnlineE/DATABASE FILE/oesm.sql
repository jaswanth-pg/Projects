-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 02, 2022 at 10:44 AM
-- Server version: 10.4.22-MariaDB
-- PHP Version: 8.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `oesm`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `email` varchar(50) NOT NULL,
  `password` varchar(500) NOT NULL,
  `gender` varchar(50) NOT NULL,
  `college` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`email`, `password`, `gender`, `college`) VALUES
('bharath@gmail.com', '123456', 'M', 'RGMCET'),
('jaswanth@gmail.com', '654321', 'M', 'RGMCET'),
('naresh_sir@rgm.com', '123456', 'M', 'RGMCET'),
('karthik@gmail.com', '123456', 'M', 'RGMCET'),
('vijay@gmail.com', '123456', 'M', 'RGMCET'),
('anitha@gmail.com', '123456', 'F', 'RGMCET'),
('sunitha@gmail.com', '123456', 'F', 'RGMCET');

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE `answer` (
  `qid` text NOT NULL,
  `ansid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`qid`, `ansid`) VALUES
('558922117fcef', '5589221195248'),
('55892211e44d5', '55892211f1fa7'),
('558922894c453', '558922895ea0a'),
('558922899ccaa', '55892289aa7cf'),
('558923538f48d', '558923539a46c'),
('55892353f05c4', '55892354051be'),
('6283615c864a9', '6283615c8982d'),
('6283615c922af', '6283615c9300d'),
('6283615c99971', '6283615c9ab3c'),
('6283615ca1f42', '6283615caa4ba'),
('6283615cb159f', '6283615cb26e1'),
('6295c8e69aefa', '6295c8e69c888'),
('6295c8e6a0fc2', '6295c8e6a1c46'),
('6295c8e6a6093', '6295c8e6a6d8a'),
('6295c8e6ac05a', '6295c8e6acd64'),
('6295c8e6b2793', '6295c8e6b4d70'),
('6295c8e6b9a5e', '6295c8e6ba9ca'),
('6295c8e6c04cd', '6295c8e6c1558'),
('6295c8e6c5c43', '6295c8e6c6b1f'),
('6295c8e6cb22a', '6295c8e6cc027'),
('6295c8e6d07be', '6295c8e6d163e');

-- --------------------------------------------------------

--
-- Table structure for table `feedback`
--

CREATE TABLE `feedback` (
  `id` text NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `subject` varchar(500) NOT NULL,
  `feedback` varchar(500) NOT NULL,
  `date` date NOT NULL,
  `time` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `email`, `subject`, `feedback`, `date`, `time`) VALUES
('62b2e919d4177', 'Mahesh', '19091A0500@gmail.com', 'fvdz', 'dfghjhgfcgbfrdcvfbhtjuk,kmnbgfdcfghfvbvgvdfgnhbgv\r\n', '2022-06-22', '12:04:09pm'),
('62b2ea71ce91c', 'dwc', '19091A0500@gmail.com', 'dc', 'fec', '2022-06-22', '12:09:53pm'),
('62b2ea891d051', 'dwc', '19091A0500@gmail.com', 'dc', 'fec', '2022-06-22', '12:10:17pm');

-- --------------------------------------------------------

--
-- Table structure for table `history`
--

CREATE TABLE `history` (
  `email` varchar(50) NOT NULL,
  `eid` text NOT NULL,
  `score` int(11) NOT NULL,
  `level` int(11) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `history`
--

INSERT INTO `history` (`email`, `eid`, `score`, `level`, `sahi`, `wrong`, `date`) VALUES
('sunnygkp10@gmail.com', '558921841f1ec', 4, 2, 2, 0, '2015-06-23 09:31:26'),
('avantika420@gmail.com', '558921841f1ec', 4, 2, 2, 0, '2015-06-23 14:33:04'),
('avantika420@gmail.com', '5589222f16b93', 4, 2, 2, 0, '2015-06-23 14:49:39'),
('mi5@hollywood.com', '5589222f16b93', 4, 2, 2, 0, '2015-06-23 15:12:56'),
('nik1@gmail.com', '558921841f1ec', 1, 2, 1, 1, '2015-06-23 16:11:50'),
('sunnygkp10@gmail.com', '5589222f16b93', 4, 2, 2, 0, '2021-04-11 16:27:21'),
('19091A0400@gmail.com', '628360460bc5d', -2, 5, 1, 4, '2022-05-22 16:28:37'),
('19091A0500@gmail.com', '558922ec03021', 1, 2, 1, 1, '2022-05-31 06:55:27'),
('19091A0400@gmail.com', '6295c6c129b01', 5, 10, 5, 5, '2022-06-10 06:42:28'),
('19091A0000@gmail.com', '628360460bc5d', -2, 5, 1, 4, '2022-06-13 14:02:37'),
('19091A0500@gmail.com', '628360460bc5d', 1, 5, 2, 3, '2022-06-14 10:00:13'),
('19091A0500@gmail.com', '5589222f16b93', -2, 2, 0, 2, '2022-06-14 10:00:29'),
('19091A0000@gmail.com', '5589222f16b93', 1, 2, 1, 1, '2022-06-14 10:02:18'),
('19091A0000@gmail.com', '6295c6c129b01', 3, 10, 3, 7, '2022-06-14 10:03:03'),
('19091A0571@gmail.com', '628360460bc5d', 4, 5, 3, 2, '2022-06-14 12:55:08'),
('19091A0500@gmail.com', '6295c6c129b01', 2, 5, 2, 3, '2022-06-22 13:50:04'),
('19091A0500@gmail.com', '558921841f1ec', 4, 2, 2, 0, '2022-06-22 13:50:23');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `qid` varchar(50) NOT NULL,
  `option` varchar(5000) NOT NULL,
  `optionid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`qid`, `option`, `optionid`) VALUES
('558922117fcef', 'echo', '5589221195248'),
('558922117fcef', 'print', '558922119525a'),
('558922117fcef', 'printf', '5589221195265'),
('558922117fcef', 'cout', '5589221195270'),
('55892211e44d5', 'int a', '55892211f1f97'),
('55892211e44d5', '$a', '55892211f1fa7'),
('55892211e44d5', 'long int a', '55892211f1fb4'),
('55892211e44d5', 'int a$', '55892211f1fbd'),
('558922894c453', 'cin>>a;', '558922895ea0a'),
('558922894c453', 'cin<<a;', '558922895ea26'),
('558922894c453', 'cout>>a;', '558922895ea34'),
('558922894c453', 'cout<a;', '558922895ea41'),
('558922899ccaa', 'cout', '55892289aa7cf'),
('558922899ccaa', 'cin', '55892289aa7df'),
('558922899ccaa', 'print', '55892289aa7eb'),
('558922899ccaa', 'printf', '55892289aa7f5'),
('558923538f48d', '255.0.0.0', '558923539a46c'),
('558923538f48d', '255.255.255.0', '558923539a480'),
('558923538f48d', '255.255.0.0', '558923539a48b'),
('558923538f48d', 'none of these', '558923539a495'),
('55892353f05c4', '192.168.1.100', '5589235405192'),
('55892353f05c4', '172.168.16.2', '55892354051a3'),
('55892353f05c4', '10.0.0.0.1', '55892354051b4'),
('55892353f05c4', '11.11.11.11', '55892354051be'),
('6283615c864a9', 'function', '6283615c89827'),
('6283615c864a9', 'program', '6283615c8982c'),
('6283615c864a9', 'pre built function', '6283615c8982d'),
('6283615c864a9', 'none of the above', '6283615c8982e'),
('6283615c922af', 'swaps a and b values', '6283615c9300d'),
('6283615c922af', 'no change', '6283615c93010'),
('6283615c922af', 'swaps addresses of both', '6283615c93011'),
('6283615c922af', 'both a and c', '6283615c93012'),
('6283615c99971', 'valid', '6283615c9ab36'),
('6283615c99971', 'invalid', '6283615c9ab3c'),
('6283615c99971', 'int is not required to specify', '6283615c9ab3e'),
('6283615c99971', 'none', '6283615c9ab3f'),
('6283615ca1f42', 'print', '6283615caa4ba'),
('6283615ca1f42', 'read', '6283615caa4be'),
('6283615ca1f42', 'type', '6283615caa4bf'),
('6283615ca1f42', 'swap', '6283615caa4c0'),
('6283615cb159f', '0', '6283615cb26d9'),
('6283615cb159f', 'prints infinity', '6283615cb26df'),
('6283615cb159f', 'error \"OutOfIndexError\"', '6283615cb26e0'),
('6283615cb159f', 'error \"ZeroDivisionError\"', '6283615cb26e1'),
('6295c8e69aefa', 'Delete  ', '6295c8e69c880'),
('6295c8e69aefa', 'Drop', '6295c8e69c888'),
('6295c8e69aefa', 'Remove', '6295c8e69c889'),
('6295c8e69aefa', ' All of the above', '6295c8e69c88a'),
('6295c8e6a0fc2', 'Standard query language', '6295c8e6a1c40'),
('6295c8e6a0fc2', 'Sequential query language', '6295c8e6a1c45'),
('6295c8e6a0fc2', ' Structured query language', '6295c8e6a1c46'),
('6295c8e6a0fc2', ' Server-side query language', '6295c8e6a1c47'),
('6295c8e6a6093', 'Conceptual view', '6295c8e6a6d8a'),
('6295c8e6a6093', 'Physical view ', '6295c8e6a6d8f'),
('6295c8e6a6093', ' Internal view', '6295c8e6a6d90'),
('6295c8e6a6093', 'External view', '6295c8e6a6d91'),
('6295c8e6ac05a', 'Oral database connectivity  ', '6295c8e6acd61'),
('6295c8e6ac05a', 'Open database connectivity', '6295c8e6acd63'),
('6295c8e6ac05a', 'Oracle database connectivity', '6295c8e6acd64'),
('6295c8e6ac05a', ' Object database connectivity', '6295c8e6acd65'),
('6295c8e6b2793', 'One level   ', '6295c8e6b4d6b'),
('6295c8e6b2793', 'Two-level', '6295c8e6b4d6f'),
('6295c8e6b2793', 'Three-level', '6295c8e6b4d70'),
('6295c8e6b2793', 'Four level', '6295c8e6b4d71'),
('6295c8e6b9a5e', 'Tuples   ', '6295c8e6ba9c2'),
('6295c8e6b9a5e', 'Attributes', '6295c8e6ba9c8'),
('6295c8e6b9a5e', 'Rows', '6295c8e6ba9c9'),
('6295c8e6b9a5e', 'Tables', '6295c8e6ba9ca'),
('6295c8e6c04cd', 'Internal Level ', '6295c8e6c1551'),
('6295c8e6c04cd', 'External Level', '6295c8e6c1558'),
('6295c8e6c04cd', 'Conceptual Level ', '6295c8e6c1559'),
('6295c8e6c04cd', ' Physical Level', '6295c8e6c155a'),
('6295c8e6c5c43', 'Drop', '6295c8e6c6b17'),
('6295c8e6c5c43', 'Update ', '6295c8e6c6b1d'),
('6295c8e6c5c43', ' Alter', '6295c8e6c6b1f'),
('6295c8e6c5c43', 'Set', '6295c8e6c6b20'),
('6295c8e6cb22a', 'Directory   ', '6295c8e6cc01f'),
('6295c8e6cb22a', 'Sub Data', '6295c8e6cc025'),
('6295c8e6cb22a', 'Warehouse', '6295c8e6cc026'),
('6295c8e6cb22a', 'Meta Data', '6295c8e6cc027'),
('6295c8e6d07be', 'New Technology File System   ', '6295c8e6d163e'),
('6295c8e6d07be', 'New Tree File System', '6295c8e6d1644'),
('6295c8e6d07be', 'New Table type File System', '6295c8e6d1645'),
('6295c8e6d07be', 'Both A and C', '6295c8e6d1646');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `eid` text NOT NULL,
  `qid` text NOT NULL,
  `qns` text NOT NULL,
  `choice` int(10) NOT NULL,
  `sn` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`eid`, `qid`, `qns`, `choice`, `sn`) VALUES
('558921841f1ec', '558922117fcef', 'what is command for print in php??', 4, 1),
('558921841f1ec', '55892211e44d5', 'which is a variable of php??', 4, 2),
('5589222f16b93', '558922894c453', 'what is correct statement in c++??', 4, 1),
('5589222f16b93', '558922899ccaa', 'which command is use for print the output in c++?', 4, 2),
('558922ec03021', '558923538f48d', 'what is correct mask for A class IP???', 4, 1),
('558922ec03021', '55892353f05c4', 'which is not a private IP??', 4, 2),
('628360460bc5d', '6283615c864a9', 'print() is a ________.', 4, 1),
('628360460bc5d', '6283615c922af', 'a, b = b, a', 4, 2),
('628360460bc5d', '6283615c99971', 'int x = 10;', 4, 3),
('628360460bc5d', '6283615ca1f42', 'choose the one which is not a built in function', 4, 4),
('628360460bc5d', '6283615cb159f', 'a = 10\r\nb = 0\r\nprint(a/b)', 4, 5),
('6295c6c129b01', '6295c8e69aefa', 'Which one of the following commands is used for removing (or deleting) a relation forms the SQL database?', 4, 1),
('6295c6c129b01', '6295c8e6a0fc2', ' The term \"SQL\" stands for', 4, 2),
('6295c6c129b01', '6295c8e6a6093', 'Which one of the following refers to the total view of the database content?', 4, 3),
('6295c6c129b01', '6295c8e6ac05a', 'The term \"ODBC\" stands for_____', 4, 4),
('6295c6c129b01', '6295c8e6b2793', 'The architecture of a database can be viewed as the ________', 4, 5),
('6295c6c129b01', '6295c8e6b9a5e', 'In the relation model, the relation are generally termed as ________', 4, 6),
('6295c6c129b01', '6295c8e6c04cd', 'Which of the following levels is considered as the level closed to the end-users?', 4, 7),
('6295c6c129b01', '6295c8e6c5c43', 'Which one of the following commands is used to modify a column inside a table?', 4, 8),
('6295c6c129b01', '6295c8e6cb22a', 'Which one of the following refers to the \"data about data\"?', 4, 9),
('6295c6c129b01', '6295c8e6d07be', 'The term \"NTFS\" refers to which one of the following?', 4, 10);

-- --------------------------------------------------------

--
-- Table structure for table `quiz`
--

CREATE TABLE `quiz` (
  `eid` text NOT NULL,
  `title` varchar(100) NOT NULL,
  `sahi` int(11) NOT NULL,
  `wrong` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `time` bigint(20) NOT NULL,
  `intro` text NOT NULL,
  `tag` varchar(100) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `quiz`
--

INSERT INTO `quiz` (`eid`, `title`, `sahi`, `wrong`, `total`, `time`, `intro`, `tag`, `date`) VALUES
('558921841f1ec', 'Php Coding', 2, 1, 2, 5, '', 'PHP', '2015-06-23 09:06:12'),
('5589222f16b93', 'C++ Coding', 2, 1, 2, 5, '', 'c++', '2015-06-23 09:09:03'),
('558922ec03021', 'Networking', 2, 1, 2, 5, '', 'networking', '2015-06-23 09:12:12'),
('628360460bc5d', 'Python', 2, 1, 5, 4, 'correct ans : +2\r\nwrong ans : -1\r\ntotal qns : 5\r\nduration : 4 min\r\n--ALL THE BEST --', 'python', '2022-05-17 08:43:50'),
('6295c6c129b01', 'Dbms', 1, 0, 10, 10, 'DBMS test', '#dbms', '2022-05-31 07:41:53');

-- --------------------------------------------------------

--
-- Table structure for table `rank`
--

CREATE TABLE `rank` (
  `email` varchar(50) NOT NULL,
  `score` int(11) NOT NULL,
  `time` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rank`
--

INSERT INTO `rank` (`email`, `score`, `time`) VALUES
('19091A0500@gmail.com', 9, '2022-06-22 13:50:23'),
('19091A0400@gmail.com', 5, '2022-06-10 06:42:28'),
('19091A0000@gmail.com', 2, '2022-06-14 10:03:03'),
('19091A0571@gmail.com', 4, '2022-06-14 12:55:08');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `name` varchar(50) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `college` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `mob` bigint(20) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`name`, `gender`, `college`, `email`, `mob`, `password`) VALUES
('Student', 'M', 'RGMCET', '19091A0000@gmail.com', 0, 'e10adc3949ba59abbe56e057f20f883e'),
('Ex', 'F', 'RGMCET', '19091A0400@gmail.com', 0, 'e10adc3949ba59abbe56e057f20f883e'),
('Bbk', 'M', 'RGMCET', '19091A0500@gmail.com', 0, 'e10adc3949ba59abbe56e057f20f883e'),
('Mukkara Mahesh', 'M', 'RGMCET', '19091A0571@gmail.com', 0, 'e10adc3949ba59abbe56e057f20f883e'),
('Studentx', 'F', 'RGMCET', '19091A05xx@gmail.com', 0, 'e10adc3949ba59abbe56e057f20f883e');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`email`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
