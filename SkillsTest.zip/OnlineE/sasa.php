<?php

/*
require_once __DIR__ . '\vendor\autoload.php';
$mpdf = new \Mpdf\Mpdf();




//require_once("mpdf/mpdf");  ---------*/

$name = $_POST['user'];
$score = $_POST['userscore'];
//echo $name." got ".$score."<br>";
$dt = date('jS-F-Y');


echo "<html>
		<head>
			//<script src='https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js' integrity='sha512-GsLlZN/3F2ErC5ifS5QtgpiJtWd43JWSuIgh7mbzZ8zBps+dvLusV+eNQATqgA/HdeKFVgA5v3S/cIrLF7QnIg==' crossorigin='anonymous' referrerpolicy='no-referrer'></script>
			<script>function printpage() {
					var printButton = document.getElementById('printpagebutton'); 
					
					printButton.style.visibility = 'hidden';
					window.print()
					printButton.style.visibility = 'visible';
					 //html2pdf().from(printButton).save();
					}
			</script>
			<style>
				#certificate{
					width : 100%;
					background-image : linear-gradient(#B8FFF9,#85F4FF,#42C2FF);
					border-style: solid;
					border-color : black;
					border-width : 5px;
					font-family: Georgia, serif;
					-webkit-print-color-adjust: exact; 
					border-radius : 20px;
				}
				.headd{
					font-family: 'Times New Roman', serif;
				}
				.sub{
					font-family: 'Courier New', Courier, monospace;
				}
				.sre{
					font-family: font-family: Arial, sans-serif;
				}
			</style>
		</head>
	<body>
	<div id = 'certificate'>
	<form > 
		<table align = 'center'>
		<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr align = 'center'><th><h1><u><div class='headd'>CERTIFICATE OF COURSE COMPLETION</div></u></h1></th></tr>
			<tr align = 'center'><td><h2><div class='sub'>This is to certify that</div></h2></td></tr>
			<tr align = 'center'><td><h1><b>Mr/Ms   $name</b></h1></td></tr>
			<tr align = 'center'><td><h2><div class = 'sub'>has completed the assessment</div></h2></td></tr>
			<tr align = 'center'><td><h2>with the score of $score</h2></td></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr><tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
			<tr></tr>
		</table>
		<table align = 'center' >
			<tr align = 'center'><td align = 'center'><h3>$dt</h3></td>
		
		<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
			<td align = 'center'><img src = 'signature.png'width = '100px' height = '10px'></img></td>
			
			</tr>
			<tr align = 'center'><td align = 'center'><h2>Completion date</h2></td>
			<td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td><td></td>
			<td align = 'center'><h2>Signature</h2></td>
			</tr>
		</table>
		<center><input id='printpagebutton' type='button' value='download' onclick='printpage()' /></center> 
		</form></div>
	</body>
</html>";







?>

